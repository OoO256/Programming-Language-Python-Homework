while True:
    print('I am in an endless loop')
    ans = input('Do you want to exit? (y / n) ')
    if ans == 'y':
        break
